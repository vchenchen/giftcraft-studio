# 精准修改单 / Scoped revision request
- 请求编号与版本 / Request ID and version:
- 最新源图：文件名、路径、版本 / Latest source: filename, path, version:
- 修改位置或区域 / Edit location or region:
- 原内容 → 新内容（逐字） / Old → new content, verbatim:
- 允许修改项 / Allowed changes:
- 冻结项：背景、角度、结构、材质、光线、比例、Logo及其他文案 / Frozen: background, angle, structure, material, light, scale, marks and other copy:
- 输出尺寸与格式 / Output dimensions and format:
- 验证：修改正确、未新增元素、区域外对照、残留原字 / Verify replacement, no additions, outside-region comparison, no old copy remnants:
- 发现偏差与处置 / Deviations and resolution:
- 通过、待修或待用户判断 / Pass, rework or user judgment:


流程约束 / Workflow constraints v1.1.0: 设计阶段不提供数字成本估价；预算未获报价验证须标待核实。交期由用户与制造商确认，不预测或承诺。姓名编号只预留位置，不收集名单。局部改图漂移须展示偏差并由用户决定，不自动修正。
No design-stage numerical product-cost estimates. Budget compliance awaits a real quote; delivery is confirmed by user and manufacturer. Reserve personalization positions without lists. Show unintended image drift and wait for the user’s decision.
