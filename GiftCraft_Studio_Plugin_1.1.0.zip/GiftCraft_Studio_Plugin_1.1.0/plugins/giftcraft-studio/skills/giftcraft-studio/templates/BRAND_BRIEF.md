# 品牌简报 / Brand brief
## 六项开场字段 / Six opening fields
- 品牌名称 / Brand name:
- 行业 / Industry:
- 赠送对象 / Recipients:
- 纪念场景 / Occasion:
- 采购数量 / Quantity:
- 单件预算：币种、包装及运费口径 / Budget: currency, packaging/freight basis:
## 补充记录 / Context
- 已核实品牌背景与来源 / Verified background and sources:
- 官方Logo、参考图、角色及版本 / Official logo, references, roles and versions:
- 背景是否足够；素材是否齐全（分别记录） / Background sufficient; assets complete, separately:
- 缺背景时用户选择：官方资料联网查找或自行补充 / Research or supplied-information choice:
- 预算/数量选项及用户选择 / Scenario-specific budget/quantity bands and user choices:
- 必须保留、排除及指定品类 / Invariants, exclusions, specified category:
- 已知事实、假设、待核实 / Facts, assumptions, unknowns:
- 交期：由用户与制造商确认，不设为开场门槛 / Delivery: user/manufacturer confirmation, not an intake gate:
