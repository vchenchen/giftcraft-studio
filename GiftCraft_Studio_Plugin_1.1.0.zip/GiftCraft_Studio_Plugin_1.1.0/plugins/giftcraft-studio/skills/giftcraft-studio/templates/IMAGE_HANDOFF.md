# 五款效果图进度 / Five-image handoff
- 批准轮次与五款编号 / Approved round and five IDs:
- 满意确认及出图授权原文 / Satisfaction and image authorization:
- 官方Logo与参考图位置/角色，访问状态 / Official assets, roles and accessibility:
- 默认：每款单独一张，礼品本体、浅背景、柔光、三分之四视角 / Separate product-only images, light background, soft light, three-quarter view.

| 编号 / ID | 图片状态 / Status | 实际输出 / Actual output | 首次/重试及真实错误 / Attempts and actual error | 备用提示词 / Prompt |
|---|---|---|---|---|
| 01 | 待生成 / Pending | | | |
| 02 | 待生成 / Pending | | | |
| 03 | 待生成 / Pending | | | |
| 04 | 待生成 / Pending | | | |
| 05 | 待生成 / Pending | | | |

失败款提示词须完整自包含。明确指引：新建支持生图的对话或其他AI工具→重新上传官方Logo和参考图→粘贴提示词→生成。保留成功图，不承诺后台恢复。
Prompts must stand alone: open another image-capable chat/tool → re-upload assets → paste prompt → generate. Preserve successes; no background recovery promise.
