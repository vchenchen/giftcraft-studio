# 包装规范 / Packaging specification
- 对应产品、版本、数量 / Product, revision, quantity:
- 产品包络尺寸与重量 / Product envelope dimensions and weight:
- 盒型及开合方式 / Box structure and opening:
- 内外尺寸(mm)、板厚及待确认公差 / Inner/outer dimensions, board thickness, tolerances to confirm:
- 外包纸、裱贴、表面工艺 / Wrap, lamination and finish:
- 内衬材料、开槽、固定及拿取 / Insert material, cavities, retention and removal:
- 配件与保护 / Accessories and protection:
- 盒外Logo、中央文案、底部落款（精确文本） / Exterior mark, center copy, footer, exact text:
- 字体、字号、位置、最小线宽待工厂确认 / Type, size, placement, minimum line width for factory review:
- 色彩来源：屏幕参考或实体标准 / Color source: screen reference or physical standard:
- 刀模文件、版本和审批状态 / Dieline file, version and approval:
- 运输包装、跌落测试条件待确认 / Transit pack and drop-test conditions to agree:
- 单价、打样、模具、运输税费 / Unit, sample, tooling, freight and taxes:
- 待确认事项与签样 / Open items and sample approval:


流程约束 / Workflow constraints v1.1.0: 设计阶段不提供数字成本估价；预算未获报价验证须标待核实。交期由用户与制造商确认，不预测或承诺。姓名编号只预留位置，不收集名单。局部改图漂移须展示偏差并由用户决定，不自动修正。
No design-stage numerical product-cost estimates. Budget compliance awaits a real quote; delivery is confirmed by user and manufacturer. Reserve personalization positions without lists. Show unintended image drift and wait for the user’s decision.
