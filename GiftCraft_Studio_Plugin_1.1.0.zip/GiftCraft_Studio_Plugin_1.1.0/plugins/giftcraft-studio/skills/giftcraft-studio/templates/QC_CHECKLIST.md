# 质量检查 / QC checklist
产品、批次、版本、检查人和日期 / Product, lot, revision, inspector and date:
抽样数量、验收标准与来源 / Sample size, acceptance criteria and source:
记录每项通过/失败/待核实/不适用，并附证据。
Record pass/fail/pending/not applicable with evidence for each check.

| 检查项 / Check | 标准或签样 / Standard or golden sample | 结果 / Result | 证据及处置 / Evidence and remedy |
|---|---|---|---|
| 尺寸重量及公差 / Dimensions, weight, tolerances | | | |
| 材料及表面工艺 / Material and finish | | | |
| Logo、文案、位置 / Marks, copy, placement | | | |
| 色差、刮擦、腐蚀 / Color, scratches, corrosion | | | |
| 连接强度、边缘安全 / Attachment strength, edge safety | | | |
| 内衬贴合、拿取与开合 / Insert fit, removal, closure | | | |
| 数量、个性化与装箱 / Count, personalization, packing | | | |
| 实际设计相关测试 / Design-specific tests | | | |

未决项、返工复查与放行负责人 / Open issues, reinspection and release owner:
不得把未定义的测试或未检查批次记录为通过。
Do not mark undefined tests or uninspected lots as passed.


流程约束 / Workflow constraints v1.1.0: 设计阶段不提供数字成本估价；预算未获报价验证须标待核实。交期由用户与制造商确认，不预测或承诺。姓名编号只预留位置，不收集名单。局部改图漂移须展示偏差并由用户决定，不自动修正。
No design-stage numerical product-cost estimates. Budget compliance awaits a real quote; delivery is confirmed by user and manufacturer. Reserve personalization positions without lists. Show unintended image drift and wait for the user’s decision.
