# 礼品方案 / Gift concept
- 轮次及编号 / Round and stable ID:
- 品类、名称及一句话概念 / Type, name and concept:
- 实用/品牌特色/收藏纪念侧重 / Practical, brand-specific or collectible emphasis:
- 受众价值及品牌联系（来源） / Recipient value, brand connection and evidence:
- 造型、目标尺寸(mm)、材料、工艺 / Form, target dimensions, material, process:
- 官方标识及精确文案 / Official mark and exact approved copy:
- 姓名/编号仅预留区域，不收集名单 / Reserved personalization area, no lists:
- 简短包装建议（不自动出包装图） / Brief packaging suggestion, no unsolicited render:
- 成本驱动与量产风险；成熟工艺简化方案 / Cost drivers, feasibility risks, mature-process simplification:
- 成本待制造商询价确认，尚未确认符合预算。 / Supplier quotation required; budget compliance is not yet confirmed.
- 定制/开模的成本及交期由用户与制造商确认 / User to confirm custom/tooling costs and delivery with manufacturer:
- 本轮评分及证据限制 / Score and evidence limitations:
- 用户反馈：保留/替换、原因 / Feedback: keep/replace and reason:
设计阶段不报产品价格估算，不编造MOQ或交期。 / No product-price estimates, invented MOQ or lead times.
