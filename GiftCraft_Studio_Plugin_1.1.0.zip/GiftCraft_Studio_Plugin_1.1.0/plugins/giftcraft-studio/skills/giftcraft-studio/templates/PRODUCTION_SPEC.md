# 生产规格 / Production specification
- 产品ID、版本、日期及审批状态 / Product ID, revision, date, approval status:
- 带单位尺寸、重量、公差 / Dimensions with units, weight, tolerances:
- 材料牌号与替代料审批 / Material grade and substitution approval:
- 表面工艺、色样、耐磨与防腐要求 / Finish, color sample, wear and corrosion requirements:
- 五金、连接件、装配及边缘处理 / Hardware, connections, assembly and edge treatment:
- Logo矢量、文字排版及最小工艺线宽 / Vector marks, typeset copy and minimum process line width:
- 包装刀模、内衬及装箱 / Dieline, insert and carton configuration:
- 适用市场、用途、相关测试待确认 / Market, use and applicable testing to confirm:
- 打样、工程审查、签样与量产放行 / Prototype, engineering review, golden sample and production release:
- 附件清单、负责人及未决项 / Attachments, owners and open issues:


流程约束 / Workflow constraints v1.1.0: 设计阶段不提供数字成本估价；预算未获报价验证须标待核实。交期由用户与制造商确认，不预测或承诺。姓名编号只预留位置，不收集名单。局部改图漂移须展示偏差并由用户决定，不自动修正。
No design-stage numerical product-cost estimates. Budget compliance awaits a real quote; delivery is confirmed by user and manufacturer. Reserve personalization positions without lists. Show unintended image drift and wait for the user’s decision.
