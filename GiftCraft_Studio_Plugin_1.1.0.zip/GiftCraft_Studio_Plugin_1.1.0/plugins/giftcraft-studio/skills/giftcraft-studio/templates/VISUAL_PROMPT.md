# 效果图提示词 / Visual prompt
- 任务：新图或编辑 / Task: new image or edit:
- 概念编号与目标资产 / Concept ID and target asset:
- 产品形态、比例、材质与连接结构 / Form, scale, material and connections:
- 品牌参考图与资产版本 / Brand reference and asset version:
- 精确文案（逐字保留） / Exact copy, preserve verbatim:
- Logo位置、尺寸和留白 / Logo placement, size and clear space:
- 视角、背景、光线与构图 / Camera, background, lighting and composition:
- 禁止新增项 / Forbidden additions:
- 编辑允许项及冻结项 / Allowed edits and frozen elements:
- 检查：文字、Logo、结构、尺寸感、非编辑区域 / Check text, marks, construction, scale and untouched areas.
效果图仅供概念评审；精确标识文字需正式资产核对。
Concept review only; verify exact marks and copy against official assets.


流程约束 / Workflow constraints v1.1.0: 设计阶段不提供数字成本估价；预算未获报价验证须标待核实。交期由用户与制造商确认，不预测或承诺。姓名编号只预留位置，不收集名单。局部改图漂移须展示偏差并由用户决定，不自动修正。
No design-stage numerical product-cost estimates. Budget compliance awaits a real quote; delivery is confirmed by user and manufacturer. Reserve personalization positions without lists. Show unintended image drift and wait for the user’s decision.
