#!/usr/bin/env python3
"""Validate an extracted GiftCraft skill or its ZIP, without dependencies."""
import csv, hashlib, io, json, re, sys, zipfile
from pathlib import Path, PurePosixPath

def validate(target):
    if target.is_file():
        with zipfile.ZipFile(target) as z:
            names = z.namelist()
            if len(names) != len(set(names)):
                raise ValueError('Duplicate ZIP entries')
            for n in names:
                p = PurePosixPath(n)
                if p.is_absolute() or '..' in p.parts or '\\' in n or ':' in n:
                    raise ValueError('Unsafe ZIP path: ' + n)
                if not n.startswith('giftcraft-studio/'):
                    raise ValueError('Unexpected ZIP root: ' + n)
                if (z.getinfo(n).external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError('Symlink is not allowed: ' + n)
            bad = z.testzip()
            if bad:
                raise ValueError('CRC failure: ' + bad)
            files = {n[len('giftcraft-studio/'):]: z.read(n) for n in names if not n.endswith('/')}
    else:
        files = {}
        for p in target.rglob('*'):
            if p.is_symlink():
                raise ValueError('Symlink is not allowed: ' + str(p))
            if p.is_file():
                files[p.relative_to(target).as_posix()] = p.read_bytes()
    required = {'SKILL.md', 'README.md', 'MANIFEST.json', 'agents/openai.yaml',
                'scripts/validate_package.py', 'references/CHANGE_ONLY.md',
                'references/CROSS_INDUSTRY_CASES.md', 'references/ACCEPTANCE_SCENARIOS.md'}
    required.update('templates/' + n for n in (
        'BRAND_BRIEF.md','CONCEPT_CARD.md','CONCEPT_SCORECARD.csv','VISUAL_PROMPT.md',
        'PACKAGING_SPEC.md','REVISION_REQUEST.md','PRODUCTION_SPEC.md','SUPPLIER_RFQ.md','QC_CHECKLIST.md','IMAGE_HANDOFF.md'))
    missing = required - files.keys()
    if missing:
        raise ValueError('Missing required files: ' + ', '.join(sorted(missing)))
    manifest = json.loads(files['MANIFEST.json'])
    expected = manifest['files']
    actual = set(files) - {'MANIFEST.json'}
    if set(expected) != actual:
        raise ValueError('Manifest inventory mismatch')
    for n, digest in expected.items():
        if hashlib.sha256(files[n]).hexdigest() != digest:
            raise ValueError('Hash mismatch: ' + n)
        if not files[n].strip():
            raise ValueError('Empty file: ' + n)
    skill = files['SKILL.md'].decode('utf-8')
    if not re.match(r'\A---\nname: giftcraft-studio\ndescription: [^\n]+\n---\n', skill):
        raise ValueError('Invalid skill frontmatter')
    checked = 0
    for n, data in files.items():
        if not n.endswith('.md'):
            continue
        body = data.decode('utf-8')
        for ref in re.findall(r'\]\(([^)]+)\)', body):
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', ref) or ref.startswith('#'):
                continue
            ref = ref.split('#')[0]
            p = PurePosixPath(n).parent / ref
            parts = []
            for part in p.parts:
                if part == '..':
                    if not parts:
                        raise ValueError('Reference escapes package: ' + ref)
                    parts.pop()
                elif part != '.':
                    parts.append(part)
            resolved = '/'.join(parts)
            if resolved not in files:
                raise ValueError('Broken relative link in ' + n + ': ' + ref)
            checked += 1
        # Also validate literal resource references in the entry point.
        if n == 'SKILL.md':
            for ref in re.findall(r'`((?:templates|references|scripts)/[^`\s]+)`', body):
                if ref not in files:
                    raise ValueError('Missing resource: ' + ref)
    rows = list(csv.reader(io.StringIO(files['templates/CONCEPT_SCORECARD.csv'].decode())))
    if rows[0] != ['round_id','concept_id','concept_name','criterion','weight_percent','score_1_5','weighted_points','evidence_and_uncertainty','budget_gate','branding_gate','safety_gate','recommendation_reason']:
        raise ValueError('Invalid scorecard schema')
    print(f'PASS: {len(files)} files; {checked} relative links; hashes, templates and archive paths verified.')

if __name__ == '__main__':
    try:
        validate(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1])
    except Exception as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(1)
