# GiftCraft Studio · 礼创工坊 v1.1.0
面向企业市场、品牌和行政人员的中英文纪念礼品创意与效果图工具。
Bilingual concepts and visuals for non-designer enterprise gift planners.

## 安装 / Installation
解压并将完整 `giftcraft-studio` 文件夹放入 `$CODEX_HOME/skills/`，未设置时使用 `~/.codex/skills/`；先备份已有安装。新建对话用 `$giftcraft-studio` 调用，未刷新则重启应用。
Copy the full extracted skill into the user skill directory; back up an existing installation. Invoke `$giftcraft-studio` in a new chat, restarting if discovery has not refreshed.

## 新版流程 / Workflow
简短介绍功能→六项表单（品牌、行业、对象、场景、数量、预算）→品牌背景与Logo分别检查→五款方案及场景评分推荐→询问满意→不满意了解原因后再出新的五款→满意并确认出图且素材齐备→五张分别生成的礼品本体图→用户选款后决定改图、包装或生产建议。
Brief opening → six-field intake → separate brand and asset checks → five concepts and scenario-adjusted scores → satisfaction loop → explicit image authorization and assets → five separate product-only visuals → user-selected next step.

预算/数量未知则按场景提供档位，不代用户默认选择。无报价不承诺预算内、不报数字成本估价。交货期由用户与制造商确认。默认排除食品酒类保健品、电池电子类和易碎笨重不便携带品；只预留个性化位置，不处理名单。
Unknown budget/quantity leads to scenario choices, not invented costs. All quote/delivery checks stay with manufacturers. No personalization lists.

内含10个模板、跨行业案例、验收场景与标准库验证脚本。内置图片工具无需自行配置API Key；失败款重试一次后给完整跨工具提示词，保留成功图。图片漂移由用户决定是否修正。
Includes ten templates, industry examples, acceptance scenarios and a standard-library validator. Image tools depend on the host; no new image service is bundled. Partial failures preserve successes and deliver prompts. Visual drift requires user choice.

## 验证 / Validation
在技能目录运行 `python3 scripts/validate_package.py`，或传入技能ZIP路径。Python 3.9+，无第三方依赖。
验证清单、哈希、相对资源链接和动态评分CSV结构；不等于真实生图服务恢复或模型行为通过。
Checks inventory, hashes, relative resources and the dynamic scorecard structure; not proof of live model/image behavior.

未添加MIT或其他开源许可。此版本的本地修改不自动发布到GitHub/SkillHub。
No MIT or other open-source license has been added. Local updates are not automatically published.
