# 精准修改 / Scoped edits
1. Read the latest designated image and record exact allowed changes and frozen elements. If missing, request that source. / 读取指定最新图；缺失则索取，不用旧图替代。
2. Use the revision template, preserve camera, background, lighting, geometry, material, layout and unrelated copy/marks. / 仅改指定区域，其余冻结。
3. Inspect the returned image inside and outside the requested region. A successful tool response does not prove the edit respected invariants. / 工具成功不等于精准修改成功，须检查区内及区外。
4. If unrelated drift exists, deliver the result with specific deviations and ask whether to accept or correct. Do not automatically retry a visual revision. User choice comes first. / 出现额外改动，展示并指出偏差，交用户决定接受或修正，不自动重改。
5. Pixel identity is not assumed. For exact commercial artwork use editable sources or precise typesetting when available and authorized. / 不声称像素一致；精确商用文字与Logo按正式源文件核对。

Nautilus-style example (illustrative): only replace the central lid wording; freeze logo, color, texture, footer, insert, gift, camera and shadows. If the box color drifts, show and name that deviation; wait for the user's next decision. Do not invent heritage or dates.
示范：只换盒盖中央文字，冻结其他全部；若盒色漂移，明确指出，等待用户决策。
