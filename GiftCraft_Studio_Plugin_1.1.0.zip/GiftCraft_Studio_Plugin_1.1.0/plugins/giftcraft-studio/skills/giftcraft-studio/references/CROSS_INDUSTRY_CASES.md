# 跨行业示例 / Cross-industry examples
Illustrative ideas, not verified brand facts, quotes or live test results. For each real brand, establish its own evidence and official assets. No numerical cost or lead-time estimates.
均为示范，不是官方品牌事实或报价；真实任务须重新核对品牌资料。

- 健身/Nautilus风格 / Fitness: practical cable organizer, verified-equipment silhouette keyring, training-log cover, mechanical desk object, collectible medal. Choose five distinct types across use/brand/commemoration, with mature construction and no inferred heritage. 包装另按用户选择开展，精准修改出现偏差由用户决定。
- 酒店旅游 / Hospitality: luggage tag, textile travel pouch, destination bookmark, architectural desk object, commemorative pin. Use verified destination cues; avoid fragile/heavy execution and invented hotel ratings.
- 汽车制造 / Automotive: keyring, document wallet, fabric tool pouch, silhouette bookmark, collectible token. Use supplied authorized assets; avoid powered accessories and copying another marque's design.
- 科技 / Technology: inert phone stand, cable organizer, notebook cover, desk tray, commemorative token. 无源手机支架不是电子产品；不推荐电池或充电功能。 No unsupported technical claims.
- 教育协会 / Education: bookmark, document folder, textile bag, alumni pin, commemorative token. Reserve personalization positions only; do not request graduate lists.
- 金融专业服务 / Professional services: card case, document wallet, desk organizer, notebook cover, commemorative medal. Avoid invented performance/award claims. Budget and delivery await manufacturer confirmation.

Use scenario-adjusted score weights, ask satisfaction after each set, and generate one product-only image for each of five approved concepts only after image authorization and asset checks.
按场景评分，问是否满意；满意、授权且素材齐备后五款各出一张本体图。
