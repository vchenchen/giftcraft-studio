# GiftCraft Studio · 礼创工坊 Plugin v1.1.0

解压整个文件夹并保留隐藏目录。在装有Codex CLI的终端运行，将路径替换为实际解压位置：
Extract the complete folder including hidden directories, then register and install:

```sh
codex plugin marketplace add /absolute/path/to/GiftCraft_Studio_Plugin_1.1.0
codex plugin add giftcraft-studio@giftcraft-local
```

如果同名本地来源仍指向旧包，先用 `codex plugin marketplace remove giftcraft-local` 移除旧来源，再添加此目录；保留旧包备份。插件来源目录应保持可访问。
If the same marketplace name points at an old package, remove that marketplace registration before adding this root. Preserve backups and keep the registered source directory accessible.

新对话调用 `$giftcraft-studio`，必要时重启。Standalone Skill和Plugin可能显示两个入口，本包不自动删除旧独立技能。
Open a new chat and invoke `$giftcraft-studio`; restart if needed. Standalone and plugin entries may coexist.

主要行为：六项开场资料、五款反馈迭代、满意并确认后五张产品本体图；不报价、不承诺制造商交期；精准改图偏差由用户决定；失败保留成功图并直接交付完整提示词。
Six-field brief, five-concept satisfaction loop, authorized five product-only images; no cost estimates or delivery promises; user decides on visual drift; partial failures preserve successes and provide prompts.

验证 / Validate: `python3 scripts/validate_plugin.py`，也可传入插件ZIP路径。完整Skill文档位于 `plugins/giftcraft-studio/skills/giftcraft-studio/README.md`。
No MIT license is included. This local version has not been published to GitHub, SkillHub or the official plugin directory.
