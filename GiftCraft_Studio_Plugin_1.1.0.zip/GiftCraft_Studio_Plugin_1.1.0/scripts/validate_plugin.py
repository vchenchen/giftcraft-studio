#!/usr/bin/env python3
import hashlib,json,subprocess,sys,tempfile,zipfile
from pathlib import Path,PurePosixPath

def validate(root):
    manifest=json.loads((root/'MANIFEST.json').read_text())
    files={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()}
    if set(files)-{'MANIFEST.json'} != set(manifest['files']):
        raise ValueError('Inventory mismatch')
    for name,digest in manifest['files'].items():
        if files[name].is_symlink() or hashlib.sha256(files[name].read_bytes()).hexdigest()!=digest:
            raise ValueError('Hash mismatch or symlink: '+name)
    market=json.loads((root/'.agents/plugins/marketplace.json').read_text())
    for entry in market['plugins']:
        rel=entry['source']['path']
        if not rel.startswith('./') or '..' in PurePosixPath(rel).parts:
            raise ValueError('Invalid marketplace path')
        plugin=root/rel
        modern=json.loads((plugin/'plugin.json').read_text())
        compat=json.loads((plugin/'.codex-plugin/plugin.json').read_text())
        assert modern['name']==compat['name']==entry['name']=='giftcraft-studio'
        assert modern['version']==compat['version']==manifest['version']=='1.1.0'
        assert compat['skills']=='./skills/'
        for config in (modern['extensions']['com.openai'],compat):
            rel=config['onboardingSkill']
            assert rel.startswith('./') and '..' not in PurePosixPath(rel).parts
            assert (plugin/rel).is_file()
        assert not (plugin/'mcp.json').exists()
        skill=plugin/'skills/giftcraft-studio'
        subprocess.run([sys.executable,str(skill/'scripts/validate_package.py'),str(skill)],check=True)
    print('PASS: plugin manifests, marketplace paths, full skill and '+str(len(files))+' file hashes.')

def main():
    target=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
    if target.is_dir():
        validate(target);return
    with zipfile.ZipFile(target) as z, tempfile.TemporaryDirectory() as temp:
        names=z.namelist()
        assert len(names)==len(set(names)), 'Duplicate entries'
        assert z.testzip() is None, 'CRC failure'
        for name in names:
            p=PurePosixPath(name)
            if p.is_absolute() or '..' in p.parts or chr(92) in name or ':' in name:
                raise ValueError('Unsafe ZIP path')
            assert p.parts[0]=='GiftCraft_Studio_Plugin_1.1.0'
            assert (z.getinfo(name).external_attr>>16)&0o170000 != 0o120000
        z.extractall(temp)
        validate(Path(temp)/'GiftCraft_Studio_Plugin_1.1.0')
if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('FAIL: '+str(exc),file=sys.stderr);sys.exit(1)
