# GiftCraft Studio · 礼创工坊 — v1.0.5
完整中英文 Codex Skill；同一技能按用户语言工作，无需安装两份。
One bilingual skill with Chinese/English templates and workflows.

## 安装 / Install
1. 解压 ZIP，得到完整的 `giftcraft-studio` 文件夹。
   Extract the ZIP; retain the entire folder and all subfolders.
2. 将整个文件夹复制到 `$CODEX_HOME/skills/`；未设置该变量时，使用 `~/.codex/skills/`。
   Copy the complete folder into `$CODEX_HOME/skills/`, or `~/.codex/skills/` if unset.
   若已有同名文件夹，先备份后替换；不要只复制 SKILL.md，也不要再嵌套一层同名目录。
   Back up an existing installation before replacing it. Avoid a double-nested folder.
3. 新建 Codex 对话；若未显示则重启应用，然后用 `$giftcraft-studio` 调用。
   Open a new chat; restart the app if discovery has not refreshed, then invoke `$giftcraft-studio`.

## 验证 / Verify
需要 Python 3.9+，验证脚本仅用标准库，不联网，不安装依赖。
Python 3.9+, standard library only, no network or extra packages.
在解压目录中运行 / From the extracted skill folder:
```sh
python3 scripts/validate_package.py
```
也可检查压缩包 / Or check the ZIP without extracting:
```sh
python3 giftcraft-studio/scripts/validate_package.py GiftCraft_Studio_1.0.5.zip
```
脚本验证文件清单、SHA-256、相对链接、必需模板、CSV评分结构、ZIP路径安全及入口名称。失败返回非零状态。
Checks inventory, hashes, relative links, required templates, scorecard schema, safe ZIP paths and skill identity. Failure returns nonzero.

## 内容 / Contents
- SKILL.md: 中英文工作流 / bilingual workflow
- templates/: 9 个中英文工作模板 / 9 bilingual working templates
- references/: 精准修改、跨行业案例、验收场景 / revision protocol, industry examples, acceptance scenarios
- scripts/validate_package.py: 完整性检查 / integrity validator
- MANIFEST.json: 文件与哈希 / file inventory and hashes

文字与策略无需专用插件；生成/编辑效果图需要环境中的图片工具，工具不可用时明确降级。工厂打样、供应商报价和生产放行不由此包自动执行。
Text workflows require no dedicated plugin. Visual work uses available image tools. This package does not automatically order samples, obtain quotes, or approve production.

现有 commemorative-gift-designer 与本技能用途重叠，可显式调用本技能避免歧义，无需删除旧技能。
The older commemorative-gift-designer overlaps; invoke this skill explicitly if both are installed.

## v1.0.5 开场引导 / Opening intake
首次调用时先介绍六项功能，再显示五项资料提示并提醒上传官方Logo及参考图。收到可用简报后，技能自动提出三方向、说明品牌联系/材料工艺/包装/成本风险并推荐一款；自动标明假设，不编造品牌历史或报价。用户无需输入这些执行指令。沿用已知信息，后续精准修改不重复引导。
On first activation, present the six capabilities first, followed by the five-field intake and asset-upload reminder. Once briefed, automatically propose three directions, cover brand connection, materials/processes, packaging and cost risks, and recommend one. Label assumptions and never invent brand history or quotations. Users need not enter these execution instructions. Reuse known details and avoid repeated onboarding during revisions.

## 制图失败恢复 / Image failure recovery
v1.0.5: 默认内置制图，无需自行配置Key；同一任务连续失败两次后停止自动重试，保存续作资料与可复用提示词。API仅为用户明确选择的独立备用方式。本更新不修复外部图片服务故障，也不证明实时制图已恢复。
Built-in image tools are preferred without a user API key. After two consecutive failures, stop automatic retries and save a resumable handoff. API fallback requires explicit selection. This update does not repair external service outages or establish live generation recovery.

## v1.0.5 跨对话与跨工具续作 / Cross-chat and cross-tool handoff
多次生图失败时，当轮直接给出完整可复制提示词及使用步骤，用户可在支持生图的新对话或其他AI生图工具继续。提醒重新上传Logo及参考图；不保证新对话能修复服务故障。
After repeated image failures, immediately provide a complete, self-contained prompt and steps for use in a separate image-capable chat or another AI image tool. Remind the user to re-upload assets; a new chat does not guarantee service recovery.
