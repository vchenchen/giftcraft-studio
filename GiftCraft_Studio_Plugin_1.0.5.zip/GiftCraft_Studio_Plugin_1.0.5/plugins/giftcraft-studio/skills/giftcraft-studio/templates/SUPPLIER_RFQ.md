# 供应商询价单 / Supplier RFQ
项目 / Project:
询价联系人 / Enquiry contact:
选定概念、图纸及版本 / Selected concept, drawing and revision:
目的地、币种、贸易条款待确认 / Destination, currency and trade terms to agree:

请分别报价；未知处填写待确认，不得视为已承诺。
Quote separately; mark unknowns for confirmation rather than treating them as commitments.

| 项目 / Item | 100件 | 300件 | 500件 | 1000件 | 说明 / Notes |
|---|---|---|---|---|---|
| 产品 / Product | | | | | |
| 包装 / Packaging | | | | | |
| 个性化 / Personalization | | | | | |
| 单次模具费 / One-time tooling | | | | | |
| 打样费 / Sample fee | | | | | |
| 运费与税费 / Freight and taxes | | | | | |

- 最低起订量、报价有效期、付款条款 / MOQ, quote validity, payment terms:
- 打样及量产交期起算条件 / Sample and production lead-time triggers:
- 材料、工艺、尺寸公差与替代方案 / Materials, process, tolerances and alternatives:
- 品牌稿、色样、刀模及样品审批 / Artwork, color, dieline and sample approval:
- 质检方法、抽样方案与缺陷处理 / QC method, sampling plan and defect remedy:
- 模具归属、返工及补货责任 / Tooling ownership, rework and replacement responsibility:
此模板为询价草稿，不自动发送或构成采购订单。
This is an RFQ draft, not an automatically sent message or purchase order.
