# 效果图提示词 / Visual prompt
- 任务：新图或编辑 / Task: new image or edit:
- 概念编号与目标资产 / Concept ID and target asset:
- 产品形态、比例、材质与连接结构 / Form, scale, material and connections:
- 品牌参考图与资产版本 / Brand reference and asset version:
- 精确文案（逐字保留） / Exact copy, preserve verbatim:
- Logo位置、尺寸和留白 / Logo placement, size and clear space:
- 视角、背景、光线与构图 / Camera, background, lighting and composition:
- 禁止新增项 / Forbidden additions:
- 编辑允许项及冻结项 / Allowed edits and frozen elements:
- 检查：文字、Logo、结构、尺寸感、非编辑区域 / Check text, marks, construction, scale and untouched areas.
效果图仅供概念评审；精确标识文字需正式资产核对。
Concept review only; verify exact marks and copy against official assets.
