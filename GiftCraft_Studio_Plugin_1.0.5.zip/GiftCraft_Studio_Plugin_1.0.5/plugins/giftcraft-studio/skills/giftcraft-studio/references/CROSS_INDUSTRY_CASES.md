# 跨行业案例 / Cross-industry cases
All cases are illustrative exercises, not verified supplier quotes or a reconstruction of unavailable historical images. Budgets and dates must come from the live brief.
以下均为示范场景，不是已核实报价，也不是对缺失历史图片的复刻；预算日期以当前简报为准。

## 1. 健身 · Nautilus 经销商纪念品 / Fitness distributor keepsake
Input: official Nautilus assets, distributor audience, ten concepts requested.
Develop: use verified equipment silhouettes, mechanical form and training culture as distinct cues. Explore a machine-silhouette keyring, a moving mechanical desk keepsake, and a collectible training token rather than recoloring one logo tag. Score ten ideas and recommend signature/core/playful options.
Packaging: fit the selected object in a rigid lid-and-base box with a shaped insert; use only supplied brand colors and exact copy. Show open box plus lid when requested.
Revision: when asked to replace one central line, freeze all other elements and compare before/after. Do not invent anniversary dates, heritage facts or historical slogans.
中文要点：官方资产→十款从理性到奇思妙想→评分选款→盒型与定制内衬→仅修改指定文字→工厂审核和签样。未提供的历史信息不补写。

## 2. 酒店旅游 / Hospitality
Audience: returning VIP guests. Brand cues: supplied architectural details and verified destination motif.
Directions: tactile room-key-inspired luggage tag; miniature architectural desk object; travel ritual keepsake box. Compare retention value, luggage weight and delivery cost. Validate leather/material claims; never invent hotel heritage or star ratings.
中文：从建筑与旅行仪式提取符号，比较使用频率、携带重量和成本；包装兼顾旅行耐压与拿取。

## 3. 汽车制造 / Automotive
Audience: owner-club milestone event. Use authorized vehicle silhouette or engineering detail.
Directions: silhouette keyring, machined desk piece, interactive wheel-inspired collectible. Specify edge finish, attachment durability and packaging retention. Marks and vehicle forms require supplied authorized assets; do not imply OEM approval.
中文：以车型轮廓或机械工艺建立独特性，核对授权、边缘和连接强度，不暗示官方认证。

## 4. 科技 / Technology
Audience: enterprise partners. Use supplied product geometry or interface motif.
Directions: circuit-inspired desk object, modular cable organizer, interactive mechanical token. Compare useful daily interaction with perceived novelty. Avoid unsupported chip specifications; an inert collectible does not require a battery design.
中文：产品几何与交互语言转为可用或可收藏物件，避免虚构技术参数，按实际功能确认测试。

## 5. 教育与协会 / Education and associations
Audience: graduates or certification recipients. Use verified crest, campus geometry and exact program name.
Directions: numbered pin, architectural bookend, milestone token. Check name accuracy and personalization proof before batch production; keep individual recipient data out of shared public mockups.
中文：徽章、建筑书挡或里程碑纪念章，量产前逐项校对姓名与课程文字。

## 6. 金融与专业服务 / Finance and professional services
Audience: long-term clients. Use supplied visual identity and verified partnership milestone.
Directions: restrained desk medallion, document-weight sculpture, personalized archive box. Compare symbolic relevance and daily display value; avoid invented financial performance or award claims.
中文：以合作纪念、桌面陈列和工艺质感为重点，不写未经证实的业绩与荣誉。
