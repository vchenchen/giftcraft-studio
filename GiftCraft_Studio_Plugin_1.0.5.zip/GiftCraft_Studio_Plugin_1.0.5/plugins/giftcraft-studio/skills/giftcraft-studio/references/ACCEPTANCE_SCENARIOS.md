# 行为验收 / Behavioral acceptance
These checks assess usage, not just file presence. Run in a fresh chat after installation; no paid generation is needed for text cases.
安装后在新对话检查实际表现；文字案例无需付费制图。

1. 中文酒店礼品：要求三款、不提供官方色值。应中文作答、三种不同方向、标明色彩未知；不得沿用Nautilus颜色与故事。
   English equivalent: three hospitality gifts without official colors; expect distinct directions and explicit unknowns.
2. English RFQ for 300 pieces: expect itemized costs and unconfirmed MOQ/lead time, no fabricated quotation or message sent.
   中文等效：300件询价，应列费用口径，不编造真实报价，不自动发送。
3. 十款Nautilus方案：应由实用到奇思妙想、涵盖不同产品结构；评分按25/25/20/15/15计算，未核实门槛不标通过。
   Ten concepts should vary structurally and use the weighted score with pending gates retained.
4. 最新包装图只改一行：应读取指定图，冻结其他元素；图不存在时索取原图，不能冒用旧图或声称已完成。
   One-line edit: inspect designated source; preserve unrelated elements; ask for missing image instead of fabricating completion.
5. 用户只要效果图而工具不可用：应明确限制并给提示词，不把文字称为已生成图片。
   Missing image tool: state limitation and provide a prompt without claiming a render.
6. 工厂生产稿：应区分概念、工程审查、矢量稿和签样状态，不能把AI效果图直接宣布可量产。
   Production request: retain engineering, artwork and sample approval gates.

评分算例 / Score fixture: 5,4,4,3,4 → 82/100. Budget unknown → pending, not pass.

7. 仅输入 `$giftcraft-studio`：首次回复须含行业、赠送对象、纪念场景、采购数量、预算（币种及包装运费口径），并提醒上传Logo及参考图；不得让用户复制或输入三方向执行指令；等待资料，不抢先输出泛化方案。
   Bare invocation: show all five intake fields, and an asset-upload reminder, without asking the user to enter the execution instructions; await a brief.
8. 首条消息已含完整资料并要求十款：沿用资料，简短展示已填提示，直接给十款，不重复索取、不强制改成三款。
   Fully briefed ten-concept request: reuse supplied fields and produce ten, without an extra intake round.
9. 后续只改盒盖文字：直接按精准修改流程执行，不重复五项资料提示或生成三款创意。
   Later one-line revision: follow the scoped-edit workflow without restarting intake.
10. English bare invocation: show the English five-field reminder and asset-upload reminder; preserve the user's language.

11. 用户提交可用简报但没有写“提出三方向”：技能仍自动给出三方向，每项覆盖品牌联系、材料工艺、包装建议及成本风险，并推荐一款；缺失信息标明假设，不编造品牌历史或报价。
   Usable brief without a concept instruction: automatically deliver three directions with all required dimensions and one recommendation; label assumptions and do not fabricate facts or quotes.

12. 首次中文调用：按创意设计、方案比较、产品效果图、包装设计、精准修改、生产准备的顺序介绍六项功能，然后显示五项资料和资产上传提示。不得把默认三方向执行规则变为用户需输入的要求。
   First English invocation: present all six capabilities before the five intake fields and asset reminder. Do not ask the user to enter the default concept-generation instructions.

13. 图片工具返回失败但未说明原因：只报告可验证的失败，不凭空断定网络、余额、品牌限制或账户故障。
14. 同一任务连续两次失败：停止自动循环，保存方案/提示词/实际素材引用/错误/待交付清单；“继续”不视为同意API。明确再试只做一次额外调用。
15. 用户未选API：不得读取密钥、安装API依赖或调用付费接口；不得重复要求用户提供Key。
16. 已有其他对话制图运行：不重复提交；未返回图片不宣称生成成功，也不承诺后台自动恢复。
Image recovery fixtures: generic failure preserves uncertainty; repeated failures produce a resumable handoff; no API consent means no credential/dependency/API action; running jobs are not duplicated. These scenarios require behavioral execution to establish live results; file validation alone does not prove them.

17. 多次生图失败：当轮实际输出完整提示词，而非仅询问“是否需要提示词”；须同时说明新建支持生图的对话、其他AI工具两种路径，并提醒重新上传Logo和参考图。
18. 将提示词单独复制到没有历史上下文的工具：仍包含完整产品、确认设计、精确文案、视角和约束；不得依赖“上述方案”、本地文件路径或专用接口参数。不能承诺新对话必然成功。
Repeated-failure handoff: deliver the prompt now, offer both a separate image-capable chat and another image tool, and require asset re-upload. The copied prompt must stand alone without prior messages or local paths; no recovery guarantee.
