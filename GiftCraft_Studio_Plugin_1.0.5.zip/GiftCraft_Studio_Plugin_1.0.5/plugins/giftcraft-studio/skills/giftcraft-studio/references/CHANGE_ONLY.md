# 精准修改流程 / Change-only protocol
1. Inspect the most recent user-designated target. If unavailable, request that exact source; do not substitute an older similar image. / 先看用户指定的最新目标图；缺失时索取该图。
2. Record allowed changes, exact old/new text and frozen elements using the revision template. / 记录允许项、精确文案及冻结项。
3. Preserve canvas dimensions, camera, layout, light, material, box geometry, gift, insert and all unrelated marks. Instruct the image editor to change only the specified region. / 保持画幅、角度、布局、光线、材质、盒型、礼品、内衬及无关标识。
4. Compare the replacement and the surrounding pixels visually. For exact requirements use a mask, layers or vector/text overlay when supported; do not promise generative edits are pixel-identical. / 检查修改区及区外；精确要求优先用蒙版、分层或矢量排版。
5. If unrelated changes appear, correct them with a targeted retry. If repeated attempts still drift, disclose the limitation and request editable source rather than silently accepting drift. / 出现漂移做针对性修正，反复失败时说明并请求可编辑源文件。
6. Deliver the revised image with a short statement of any remaining discrepancy. / 交付修改图，仅简述未解决偏差。

## 包装示例 / Packaging example
Request: change only the central lid wording to the user's exact supplied line.
Freeze: Nautilus mark, box color, paper texture, footer, gift and insert, lid position, camera and shadows.
Accept: correct copy, unchanged placement unless required by the new text, no extra ornament or marketing line. If the line does not fit, preserve legibility and surface the layout decision rather than silently shrinking or moving all elements.
用户只改盒盖中央文字时，冻结Logo、盒色、纹理、落款、产品、内衬、盒盖位置、角度与阴影。文字装不下时说明排版决策，不擅自整体改版。
